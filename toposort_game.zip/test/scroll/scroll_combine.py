
import cv2
import numpy as np
import sys

sys.path.append("C:/Users/theleader/Desktop/games/toposort_game/test")
#print(sys.path)
from base import *


forbiddenPairs = ["blue water", "red fire" ,"green leaf", "yellow lightning"]

for scrollColor in ["blue","green","red","yellow","gray3","cyan"]:
    for symbol in ["fire","leaf", "lightning","water","spiral"]:
        if(forbiddenPairs.count(scrollColor + " " + symbol) > 0):
            continue
        else:
            scroll = toColorBrightness(cv2.imread("scroll.png",cv2.IMREAD_UNCHANGED), colors[scrollColor][0], colors[scrollColor][1], colors[scrollColor][2])
            symbol_ = cv2.imread(symbol + ".png",cv2.IMREAD_UNCHANGED)


            addTransparent(scroll, symbol_)            
            cv2.imwrite("output/scroll_" + scrollColor + "_" + symbol + ".png", scroll) #gem color , circle color
#            print(scroll)
