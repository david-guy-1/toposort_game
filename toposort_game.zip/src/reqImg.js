class reqImg{
    constructor(data,x,y){
        this.data = data // same as NPC, list of {requirements, image}
        this.x = x
        this.y = y
    }
}
export default reqImg